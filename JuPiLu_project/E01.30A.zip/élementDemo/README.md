# **Code produit**

Dans cette archive vous trouverez une partie du code produit, l'autre partie est malheureusement trop volumineuse car elle contient Storm, Kafka et Cassandra. Je mets néanmoins le lien du dépôt GitHub que nous avons essayé de faire fonctionner : https://github.com/mserrate/twitter-streaming-app 